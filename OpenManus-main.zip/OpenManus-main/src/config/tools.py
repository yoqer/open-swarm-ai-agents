# Tool configuration
BROWSER_HISTORY_DIR = "static/browser_history"